# Scale8/80 evidence transport candidate

This payload records one passing protected serial/quiescent Neon storage case:8 RUNNING,80 QUEUED,four participating tenants and a denied fifth binding without extra occupancy. It is not public HTTP/admission, worker-fleet throughput, liveness, SLA or release approval.

The exact private run4 receipt/XML/log/before-after snapshots remain immutable. Authority/domain1 migrations are REUSED; their validation executed. Domains2..5 migrated20. RED predecessors remain RED.

Canonical occupancy/rights/control rows are projected with row/full-set hashes; subject/installed_by/encoded payload values and administrative catalogues are hash-only. Actual provider locators and administrative principal literals in the3 full sources are replaced by SHA markers; every replacement is mapped. Assertions are retained; projected sources are evidence, not a runnable assigned binding.

The candidateJAR994 and private binaries stay in local custody. It differs from historical711 in17 Migrator-family entries; this archive is not self-contained offline binary reproduction or current-whole-binary equivalence to any public version. Source/class/dependency hashes are pinned; final Git closure digests and inventory review remain pending.

Root privacy review is required before incorporation/export. No network, bank, build, upload, SDK/source/inventory change is performed by this preparation.
