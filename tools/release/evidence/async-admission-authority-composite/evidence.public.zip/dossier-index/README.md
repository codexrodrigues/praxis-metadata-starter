# Dossiê publicável proposto — aguardando revisão

O ZIP privado92c9 permanece intacto. Esta versão separada projeta os três grants administrativos para full-set hash/count e troca somente locators Neon reais não essenciais por seus hashes. Dados de domínio195 já estavam omitidos; os witnesses e catálogos sintéticos necessários de authority/componente continuam como dados, não viraram hash-only.

Um subject administrativo é fixture conhecido; dois têm proveniência não confirmada e não são chamados sintéticos. Todos três são omitidos. A comparação administrativa aceita pelo root permanece vinculada aos raws privados. Nenhum valor foi impresso.

As três URI-test findings exatas foram aprovadas pelo root no recibo separado; regex intacta e fontes preservadas. Binários físicos privados ficam emA, com manifests; historical_reuse preserva evidência histórica auditada com custódia local, não reprodução binária offline autônoma. O gate oficial provará o JAR público final.

Não há upload/commit permitido por este pacote. Root ainda precisa aprovar categorias/projeções e integrar caminhos repo-relativos, closures/dependency digests da fonte final. ASYNC composite aceito preserva os runsRED; CLI12/12 é administrativo apenas; escala8/80/HTTP/Render são escopos separados.
